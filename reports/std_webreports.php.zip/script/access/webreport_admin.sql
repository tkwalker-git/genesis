-- 
-- Script to create webreport_admin table for MS Access database.
--

CREATE TABLE [webreport_admin] (
  [id] COUNTER PRIMARY KEY,
  [tablename] TEXT(250),
  [db_type] TEXT(10),
  [group_name] TEXT(250)
  );

  
