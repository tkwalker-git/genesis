<?php
header("Location: webreport.php");
?>