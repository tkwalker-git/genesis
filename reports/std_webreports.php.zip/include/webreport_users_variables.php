<?php
include(getabspath("include/webreport_users_variables_".$config["databaseType"].".php"));
?>