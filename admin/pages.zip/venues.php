<?php

require_once("database.php"); 
require_once("header.php"); 

$bc_source_id	=	$_POST["source_id"];
$bc_venue_type	=	$_POST["venue_type"];
$bc_venue_name	=	$_POST["venue_name"];
$bc_venue_address	=	$_POST["venue_address"];
$bc_venus_radius	=	$_POST["venus_radius"];
$bc_venue_lng	=	$_POST["venue_lng"];
$bc_venue_lat	=	$_POST["venue_lat"];
$bc_add_date	=	$_POST["add_date"];
$bc_status	=	$_POST["status"];
$bc_del_status	=	$_POST["del_status"];
$bc_venue_city	=	$_POST["venue_city"];
$bc_venue_state	=	$_POST["venue_state"];
$bc_venue_country	=	$_POST["venue_country"];
$bc_venue_zip	=	$_POST["venue_zip"];
$bc_categories	=	$_POST["categories"];
$bc_averagerating	=	$_POST["averagerating"];
$bc_tags	=	$_POST["tags"];
$bc_phone	=	$_POST["phone"];
$bc_neighbor	=	$_POST["neighbor"];

$frmID	=	$_GET["id"];

$action1 = isset($_POST["bc_form_action"]) ? $_POST["bc_form_action"] : "";

$action = "save";
$sucMessage = "";

$errors = array();
if ($_POST["source_id"] == "")
	$errors[] = "Source_id: can not be empty";
if ($_POST["venue_type"] == "")
	$errors[] = "Venue_type: can not be empty";
if ($_POST["venue_name"] == "")
	$errors[] = "Venue_name: can not be empty";
if ($_POST["venue_address"] == "")
	$errors[] = "Venue_address: can not be empty";
if ($_POST["venue_country"] == "")
	$errors[] = "Venue_country: can not be empty";

$err = '<table border="0" width="90%"><tr><td class="error" ><ul>';
for ($i=0;$i<count($errors); $i++) {
	$err .= '<li>' . $errors[$i] . '</li>';
}
$err .= '</ul></td></tr></table>';	

if (isset($_POST["submit"]) ) {

	if (!count($errors)) {

		 if ($action1 == "save") {
			$sql	=	"insert into venues (source_id,venue_type,venue_name,venue_address,venus_radius,venue_lng,venue_lat,add_date,status,del_status,venue_city,venue_state,venue_country,venue_zip,categories,averagerating,tags,phone,neighbor) values ('" . $bc_source_id . "','" . $bc_venue_type . "','" . $bc_venue_name . "','" . $bc_venue_address . "','" . $bc_venus_radius . "','" . $bc_venue_lng . "','" . $bc_venue_lat . "','" . $bc_add_date . "','" . $bc_status . "','" . $bc_del_status . "','" . $bc_venue_city . "','" . $bc_venue_state . "','" . $bc_venue_country . "','" . $bc_venue_zip . "','" . $bc_categories . "','" . $bc_averagerating . "','" . $bc_tags . "','" . $bc_phone . "','" . $bc_neighbor . "')";
			$res	=	mysql_query($sql);
			$frmID = mysql_insert_id();
			if ($res) {
				$sucMessage = "Record Successfully inserted.";
			} else {
				$sucMessage = "Error: Please try Later";
			} // end if res
		} // end if
		
		if ($action1 == "edit") {
			$sql	=	"update venues set source_id = '" . $bc_source_id . "', venue_type = '" . $bc_venue_type . "', venue_name = '" . $bc_venue_name . "', venue_address = '" . $bc_venue_address . "', venus_radius = '" . $bc_venus_radius . "', venue_lng = '" . $bc_venue_lng . "', venue_lat = '" . $bc_venue_lat . "', add_date = '" . $bc_add_date . "', status = '" . $bc_status . "', del_status = '" . $bc_del_status . "', venue_city = '" . $bc_venue_city . "', venue_state = '" . $bc_venue_state . "', venue_country = '" . $bc_venue_country . "', venue_zip = '" . $bc_venue_zip . "', categories = '" . $bc_categories . "', averagerating = '" . $bc_averagerating . "', tags = '" . $bc_tags . "', phone = '" . $bc_phone . "', neighbor = '" . $bc_neighbor . "' where id=$frmID";
			$res	=	mysql_query($sql);
			if ($res) {
				$sucMessage = "Record Successfully updated.";
			} else {
				$sucMessage = "Error: Please try Later";
			} // end if res
		} // end if

	} // end if errors

	else {
		$sucMessage = $err;
	}
} // end if submit
$sql	=	"select * from venues where id=$frmID";
$res	=	mysql_query($sql);
if ($res) {
	if ($row = mysql_fetch_assoc($res) ) {
		$bc_source_id	=	$row["source_id"];
		$bc_venue_type	=	$row["venue_type"];
		$bc_venue_name	=	$row["venue_name"];
		$bc_venue_address	=	$row["venue_address"];
		$bc_venus_radius	=	$row["venus_radius"];
		$bc_venue_lng	=	$row["venue_lng"];
		$bc_venue_lat	=	$row["venue_lat"];
		$bc_add_date	=	$row["add_date"];
		$bc_status	=	$row["status"];
		$bc_del_status	=	$row["del_status"];
		$bc_venue_city	=	$row["venue_city"];
		$bc_venue_state	=	$row["venue_state"];
		$bc_venue_country	=	$row["venue_country"];
		$bc_venue_zip	=	$row["venue_zip"];
		$bc_categories	=	$row["categories"];
		$bc_averagerating	=	$row["averagerating"];
		$bc_tags	=	$row["tags"];
		$bc_phone	=	$row["phone"];
		$bc_neighbor	=	$row["neighbor"];
	} // end if row
	$action = "edit";
} // end if 

?>
<form method="post" name="bc_form" enctype="multipart/form-data" action=""  >
<input type="hidden" name="bc_form_action" class="bc_input" value="<?php echo $action; ?>"/>
<table width="100%" border="0" cellspacing="0" cellpadding="5" align="center">
<tr class="bc_heading">
<td colspan="2" align="left" >Add/Edit Venue</td>
 </tr>
<tr>
<td colspan="2" align="center" class="success" ><?php echo $sucMessage; ?></td>
</tr>

<tr>
<td width="20%" align="right" class="bc_label">Venue Type:</td>
<td width="80%" align="left" class="bc_input_td">
<input type="text" name="venue_type" id="venue_type" class="bc_input" value="<?php echo $bc_venue_type; ?>" /></td>
</tr>

<tr>
<td align="right" class="bc_label">Venue Name:</td>
<td align="left" class="bc_input_td">
<input type="text" name="venue_name" id="venue_name" class="bc_input" style="width:350px" value="<?php echo $bc_venue_name; ?>" /></td>
</tr>

<tr>
<td align="right" class="bc_label">Venue Address:</td>
<td align="left" class="bc_input_td">
<input type="text" name="venue_address" id="venue_address" class="bc_input" value="<?php echo $bc_venue_address; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">Venus Radius:</td>
<td align="left" class="bc_input_td">
<input type="text" name="venus_radius" id="venus_radius" class="bc_input" value="<?php echo $bc_venus_radius; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">Longitude:</td>
<td align="left" class="bc_input_td">
<input type="text" name="venue_lng" id="venue_lng" class="bc_input" value="<?php echo $bc_venue_lng; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">Latitude:</td>
<td align="left" class="bc_input_td">
<input type="text" name="venue_lat" id="venue_lat" class="bc_input" value="<?php echo $bc_venue_lat; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">City:</td>
<td align="left" class="bc_input_td">
<input type="text" name="venue_city" id="venue_city" class="bc_input" value="<?php echo $bc_venue_city; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">State:</td>
<td align="left" class="bc_input_td">
<input type="text" name="venue_state" id="venue_state" class="bc_input" value="<?php echo $bc_venue_state; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">Country:</td>
<td align="left" class="bc_input_td"> US</td>
</tr>

<tr>
<td align="right" class="bc_label">Zip:</td>
<td align="left" class="bc_input_td">
<input type="text" name="venue_zip" id="venue_zip" class="bc_input" value="<?php echo $bc_venue_zip; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">Categories:</td>
<td align="left" class="bc_input_td">
<input type="text" name="categories" id="categories" class="bc_input" value="<?php echo $bc_categories; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">Average Rating:</td>
<td align="left" class="bc_input_td">
<input type="text" name="averagerating" id="averagerating" class="bc_input" value="<?php echo $bc_averagerating; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">Tags:</td>
<td align="left" class="bc_input_td">
<input type="text" name="tags" id="tags" class="bc_input" style="width:350px" value="<?php echo $bc_tags; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">Phone:</td>
<td align="left" class="bc_input_td">
<input type="text" name="phone" id="phone" class="bc_input" value="<?php echo $bc_phone; ?>"/></td>
</tr>

<tr>
<td align="right" class="bc_label">Neighbor:</td>
<td align="left" class="bc_input_td">
<input type="text" name="neighbor" id="neighbor" class="bc_input" value="<?php echo $bc_neighbor; ?>"/></td>
</tr>

<tr>
<td>&nbsp;</td><td align="left">
<input name="submit" type="submit" value="Save" class="bc_button" />
</td>
</tr>
</table>
</form>

<?php 
require_once("footer.php"); 
?>