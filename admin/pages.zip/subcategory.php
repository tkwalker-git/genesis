<?php
/*<?php if($r['id'] == $bc_subcategory_id){?> selected="selected" <?php } ?> */
require_once('database.php');
ini_set('display_errors', 1);  
 error_reporting(E_ALL);  
   
 // List of cities for India  
 if (isset($_GET['cat']) && $_GET['cat'] != '' ) {
  		$cat = $_GET['cat'];
		//echo $subcat = $_GET['subcat'];
		$subcat_q = "SELECT * FROM sub_categories WHERE categoryid = '$cat' ORDER BY id ASC";
		$res = mysql_query($subcat_q) or die("Error in Query");
 }

   
 ?>  
 
<select name="subcategory_id" class="bc_input">
	  <option value="">Sub Category</option> 
	  <?php 
	  	while( $r = mysql_fetch_assoc($res) ){  
	  		if ( $r['id'] == $_GET['subcat'] )
				$sele = 'selected="selected"';
			else
				$sele = '';	
	  ?>
	 <option <?php echo $sele;?> value="<?php echo $r['id']; ?>"> <?php echo $r['name']; ?></option>  
<?php } ?>
 </select>  
