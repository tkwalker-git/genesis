<?php
	
include_once('database.php');
include_once('header.php');
include_once("xmlparser.php");
$fl_cities_q = "select * from fl_cities";
$fl_cities_res = mysql_query($fl_cities_q);

?>

<div class="bc_heading">
<div>EventFull</div>
</div>
<div id="outer">
	
		<form name="flcities" id="flcities" action="" method="post">
		<div id="form">
			<div class="label"><strong> City :</strong></div>
			<div class="input">
				<select name="cities">
					<option value=""> Select City </option>
					<?php while($fl_cities_r = mysql_fetch_assoc($fl_cities_res)){ ?>
						<option value="<?php echo DBout($fl_cities_r['city']);?>"><?php echo DBout($fl_cities_r['city']);?></option>
					<?php }?>
				</select>
			</div>
			<div id="submitBtn">	
				<input type="button" value="Collect Events" onclick="document.flcities.submit()" class="addBtn">
			</div>
			<!--<input type="submit" value="submit" />-->
			</div>
		</form>
	
</div>

<div style="padding:20px">

<?php

ob_start();

if(isset($_POST['cities']) && $_POST['cities'] != ""){
	
	
	echo '<br><br><div id="loading" style="padding:20px; text-align:center"><img src="../images/loading.gif" /><br><br>Collecting data for ' . $_POST['cities'] . '</div>';

	ob_flush();
	ob_end_flush();
	ob_clean();
	
    $city = trim($_POST['cities']);
	//echo $city;
	
	$url 		= "http://api.eventful.com/rest/events/search?app_key=CSxRkR9vtmFKQTsX&location=$city,fl&date=Future&sort_orde=date&page_size=500";
	$nom 		= get_url_contents($url);
	
	$xmlparser	= new xmlparser();
	$data		= $xmlparser->GetXMLTree($nom);
	//print_r($data);
	
	$total_records 	= $data['SEARCH']['0']['TOTAL_ITEMS'][0]['VALUE'];
	$rpp			= $data['SEARCH']['0']['PAGE_SIZE'][0]['VALUE'];
	$pagecount 		= $data['SEARCH']['0']['PAGE_COUNT'][0]['VALUE'];
	$pagenum 		= $data['SEARCH']['0']['PAGE_NUMBER'][0]['VALUE'];
	
	$locations_size = sizeof($data['SEARCH']['0']['EVENTS']['0']['EVENT']);
	$total_added = 0;
	for($j=0; $j<$locations_size; $j++){
	
		$event_id 			= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['ATTRIBUTES']['ID']);
		$name				= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['TITLE']['0']['VALUE']);
		$url				= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['URL']['0']['VALUE']);
		$descr				= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['DESCRIPTION']['0']['VALUE']);
		$address			= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['ADDRESS']['0']['VALUE']);
		$start				= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['START_TIME']['0']['VALUE']);
		$stop				= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['STOP_TIME']['0']['VALUE']);
		
		$venu_id			= DBin('EF-'.$data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['VENUE_ID']['0']['VALUE']);
		$venu_name			= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['VENUE_NAME']['0']['VALUE']);
		$venu_address		= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['VENUE_ADDRESS']['0']['VALUE']);
		$venu_city			= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['CITY_NAME']['0']['VALUE']);
		$venu_state			= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['REGION_ABBR']['0']['VALUE']);
		$venu_zip			= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['POSTAL_CODE']['0']['VALUE']);
		$venu_lat			= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['LATITUDE']['0']['VALUE']);
		$venu_lon			= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['LONGITUDE']['0']['VALUE']);
		
		$owner				= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['OWNER']['0']['VALUE']);
		
		//$image				= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['IMAGE']['0']['URL']['0']['VALUE']);
		$image				= DBin($data['SEARCH']['0']['EVENTS']['0']['EVENT'][$j]['IMAGE']['0']['MEDIUM'][0]['URL']['0']['VALUE']);
		
		$owner  = str_replace("_"," ",$owner);
		
		$start_date = date("Y-m-d",strtotime($start));
		$stop_date  = date("Y-m-d",strtotime($stop));
		
		$start_time = date("g:i A",strtotime($start));
		$stop_time  = date("g:i A",strtotime($stop));
		
		//	echo $event_id . ' | ' . $name . ' | ' . $venu_name . ' | ' . $venu_address . ' | ' . $start_time . ' | ' . $stop_time . ' <br> '  ;
		
		$event_query = "insert ignore into events 
			(event_source,source_id,event_name,event_description,event_start_time,event_end_time,event_image,added_by) 
			VALUES ('EventFull','$event_id','$name','$descr','$start_time','$stop_time','$image','$owner')";
		 mysql_query($event_query) or die("event_query_error".mysql_error());
		$event_insert_id = mysql_insert_id();
		
		if($venu_id != "EF-" && $event_insert_id > 0){
			$total_added++;
			$venue_query = "insert ignore into venues (source_id,venue_name,venue_address,venue_city,venue_state,venue_zip,venue_lng,venue_lat)
			 VALUES ('$venu_id','$venu_name','$venu_address','$venu_city','$venu_state','$venu_zip','$venu_lon','$venu_lat') ";
			 mysql_query($venue_query) or die("venue_query_error".mysql_error());
				if(mysql_insert_id() == 0){
						  
						  $dup_res = mysql_query("select id from venues where source_id = '$venu_id'");
						  if($dup_r = mysql_fetch_assoc($dup_res)){$venue_insert_id = $dup_r['id'];}
						
					}elseif($event_insert_id > 0){				
						$venue_insert_id = mysql_insert_id();
					}
			
			$venue_event_query = "insert into venue_events (venue_id, event_id) values ('$venue_insert_id','$event_insert_id')";
			mysql_query($venue_event_query) or die("venue_event_query_error".mysql_error());
		}
		if($event_insert_id > 0){
			$event_dates_query = "insert into event_dates (event_id, event_date) values ('$event_insert_id', '$start_date')";
			mysql_query($event_dates_query) or die("event_dates_query_error".mysql_error());
		}
	}
	
	
	
}		
?>

</div>

<script>
document.getElementById("loading").innerHTML = '<h1><?php echo $total_added;?>' + ' Records added.</h1>';
</script>

<?php  include_once('footer.php')?>