<?php

include_once('database.php');
include_once("xmlparser.php");
include_once('header.php'); 

$fl_cities_q = "select * from fl_cities";
$fl_cities_res = mysql_query($fl_cities_q);

?>
<div class="bc_heading">
<div>MeetUp</div>
</div>
<div id="outer">
	<form name="flcities" id="flcities" action="" method="post">
		<div id="form">
			<div class="label"><strong> City :</strong></div>
			<div class="input">
				<select name="cities">
					<option value=""> Select City </option>
					<?php while($fl_cities_r = mysql_fetch_assoc($fl_cities_res)){ ?>
						<option value="<?php echo DBout($fl_cities_r['city']);?>"><?php echo DBout($fl_cities_r['city']);?></option>
					<?php }?>
				</select>
			</div>
			<div id="submitBtn">	
		<input type="button" value="Collect Events" onclick="document.flcities.submit()" class="addBtn">
		</div>
				
	</div>
   </form>
</div>


<div style="padding:20px">

<?php
ob_start();

if(isset($_POST['cities']) && $_POST['cities'] != ""){
	
	
	echo '<br><br><div id="loading" style="padding:20px; text-align:center"><img src="../images/loading.gif" /><br><br>Collecting data for ' . $_POST['cities'] . '</div>';

	ob_flush();
	ob_end_flush();
	ob_clean();
	
    $city = trim($_POST['cities']);


	$uptodate 	= date("mdY");
	$url 		= 'https://api.meetup.com/events.xml?key=7e282d6d76033699217d2f75501877&sign=true&country=US&state=fl&city=$city&after='. $uptodate .'&status=upcoming';
	
	$url 		= 'meetup_xml.xml';
	
	$xml 		= simplexml_load_file($url);
	$data 		= $xml->head;
	$total 		= $data->count;
	
	$items 	= $xml->items->item;
	$total_added = 0;
	foreach ($items as $item)
	{
		$event_id	= DBin($item->id);
		$name 		= DBin($item->name);
		$state		= DBin($item->venue_state);
		$lat		= DBin($item->venue_lat);
		$lon 		= DBin($item->venue_lon);
		$address	= DBin($item->venue_address1);
		$venu_id	= DBin("MP-".$item->venue_id);
		$descr 		= DBin($item->description);
		$fee 		= DBin($item->fee);
		$owner 		= DBin($item->organizer_name);
		$date		= DBin($item->time);
		$city 		= DBin($item->venue_city);
		$phone 		= DBin($item->venue_phone);
		$image 		= DBin($item->photo_url);
		$zip 		= DBin($item->venue_zip);
		$venu_name	= DBin($item->venue_name);
		
		$start_date = date("Y-m-d",strtotime($date));
		$start_time = date("g:i A",strtotime($date));
	
		
		//echo $event_id . ' = ' . $name . ' = ' . $start_date . ' - ' .  $start_time . '<br>';
		
		$event_query = "insert ignore into events 
			(event_source,source_id,event_name,event_description,event_start_time,event_image,added_by,event_cost) 
			VALUES ('MeetUp','$event_id','$name','$descr','$start_time','$image','$owner','$fee')";
			 
				mysql_query($event_query) or die("event_query_error".mysql_error());
				$event_insert_id = mysql_insert_id();
			
			if($venu_id != "MP-" && $event_insert_id > 0){
				$total_added++;
				$venue_query = "insert ignore into venues 
				(source_id,venue_name,venue_address,venue_city,venue_state,venue_zip,venue_lng,venue_lat,phone)
					 VALUES ('$venu_id','$venu_name','$address','$city','$state','$zip','$lon','$lat','$phone') ";
					mysql_query($venue_query) or die("venue_query_error".mysql_error());
					if(mysql_insert_id() == 0){
						$dup_res = mysql_query("select id from venues where source_id = '$venu_id'");
						 if($dup_r = mysql_fetch_assoc($dup_res)){$venue_id = $dup_r['id'];}
						
					}else{				
						$venue_insert_id = mysql_insert_id();
					}
			
				$venue_event_query = "insert into venue_events (venue_id, event_id) values ('$venue_insert_id','$event_insert_id')";
				mysql_query($venue_event_query) or die("venue_event_query_error".mysql_error());
			}
			if($event_insert_id > 0){
				$event_dates_query = "insert into event_dates (event_id, event_date) values ('$event_insert_id', '$start_date')";
				mysql_query($event_dates_query) or die("event_dates_query_error".mysql_error());
		    }
	}
}

?>
</div>
<script>
document.getElementById("loading").innerHTML = '<h1><?php echo $total_added;?>' + ' Records added.</h1>';
</script>

<?php  include_once('footer.php')?>